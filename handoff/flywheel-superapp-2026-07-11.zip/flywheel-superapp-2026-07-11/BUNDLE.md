# Flywheel Superapp bundle (2026-07-11)

Zero-dependency, runnable source distribution. Python standard library only.

## Run it

    python scripts/run_harness_cli.py app --port 8799

Then open http://127.0.0.1:8799/site/index.html

No packages to install. Fully offline for the local path. See README.md,
QUICKSTART.md, and WALKTHROUGH.md.

## Re-check the bundle

MANIFEST.sha256 lists a sha256 for every file. Recompute and compare:

    while read h f; do echo "$(sha256sum "$f" | cut -d' ' -f1)  $f"; done < MANIFEST.sha256

157 files.
